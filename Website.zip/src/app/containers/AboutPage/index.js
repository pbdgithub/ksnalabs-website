import React, { Component } from 'react';
import AboutComponent from '../../components/about-us';

class About extends Component {

  render() {
    return (
      <AboutComponent />
    );
  }
};

export default About;